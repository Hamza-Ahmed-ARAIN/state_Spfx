import * as React from "react";
import { IMarketProps } from "./IMarketProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import "./style.css";
export interface IMarketstate {
    Products: any;
}
export default class Market extends React.Component<IMarketProps, IMarketstate> {
    ProductId: number;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IMarketProps>;
    private logMessageToConsole;
    getData(id: any): Promise<any>;
}
//# sourceMappingURL=Market.d.ts.map