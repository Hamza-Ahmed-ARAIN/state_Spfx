import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IMarketProps {
  description: string;
  spfxcontext: WebPartContext;
}
