/* tslint:disable */
require("./Market.module.css");
const styles = {
  market: 'market_fb3d43d5',
  container: 'container_fb3d43d5',
  row: 'row_fb3d43d5',
  column: 'column_fb3d43d5',
  'ms-Grid': 'ms-Grid_fb3d43d5',
  title: 'title_fb3d43d5',
  subTitle: 'subTitle_fb3d43d5',
  description: 'description_fb3d43d5',
  button: 'button_fb3d43d5',
  label: 'label_fb3d43d5'
};

export default styles;
/* tslint:enable */