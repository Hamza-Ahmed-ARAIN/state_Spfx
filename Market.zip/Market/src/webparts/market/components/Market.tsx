import * as React from "react";
import styles from "./Market.module.scss";
import { IMarketProps } from "./IMarketProps";
import { escape } from "@microsoft/sp-lodash-subset";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";

import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import "./style.css";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
let url = "";
export interface IMarketstate {
  Products: any;
}
export default class Market extends React.Component<
  IMarketProps,
  IMarketstate
> {
  ProductId: number = null;
  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    // var  ProductId= parseInt(queryParms.getValue("ProductLineId"));
    this.state = {
      Products: [],
    };
    console.log("this is my id" + this.ProductId);

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
  }
  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      this.setState({ Products: Response.value });
    });
  }
  public render(): React.ReactElement<IMarketProps> {
    return (
      <div className="container">
        <div className="row">
          {this.state.Products.length > 0
            ? this.state.Products.map((item) => (
                <div className="col-sm-3">
                  <div className="pro-img" data-ride="carousel">
                    <div className="carousel-inner pro-img-inner">
                      <a
                      // href={
                      //   "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Application-categories.aspx?PeramId=" +
                      //   item.ID
                      // }
                      >
                        <img
                          className="custom-img"
                          src={item.AttachmentFiles[0].ServerRelativeUrl}
                          alt="images"
                        />

                        <div className="pro-img-text">
                          <h6>{item.Title}</h6>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              ))
            : ""}
        </div>
      </div>
    );
  }
  private logMessageToConsole(message: string) {
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    if (queryParms.getValue("PeramId")) {
      console.log(message);
    }
  }
  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Applications')/items?$select=*,AttachmentFiles,MarketCategory/ID&$expand=AttachmentFiles,MarketCategory/ID&$filter=MarketCategory/ID eq ` +
      id +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
}
