declare interface IMarketWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MarketWebPartStrings' {
  const strings: IMarketWebPartStrings;
  export = strings;
}
