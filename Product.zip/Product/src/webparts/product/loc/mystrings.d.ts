declare interface IProductWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ProductWebPartStrings' {
  const strings: IProductWebPartStrings;
  export = strings;
}
