/* tslint:disable */
require("./Product.module.css");
const styles = {

};

export default styles;
/* tslint:enable */