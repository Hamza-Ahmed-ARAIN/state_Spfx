import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IProductProps {
  description: string;
  spfxcontext:WebPartContext
}
