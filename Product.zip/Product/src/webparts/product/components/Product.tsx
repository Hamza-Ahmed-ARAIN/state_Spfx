import * as React from "react";
import styles from "./Product.module.scss";
import { IProductProps } from "./IProductProps";
import { escape } from "@microsoft/sp-lodash-subset";
import { SPComponentLoader } from "@microsoft/sp-loader";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";

let url = "";

export interface IProductstate {
  Products: any;
}

export default class Product extends React.Component<
  IProductProps,
  IProductstate
> {
  ProductId: number = null;
  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );
    this.logMessageToConsole("test done");
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    // var  ProductId= parseInt(queryParms.getValue("ProductLineId"));
    this.state = {
      Products: [],
    };
    console.log("this is my id" + this.ProductId);

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
  }

  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      this.setState({ Products: Response.value });
    });
  }

  public render(): React.ReactElement<IProductProps> {
    console.log(this.state.Products);
    return (
      <>
        <div className="head1">
          <h2>Product Line Products</h2>
          <span className="seen1">
            <a
              href="/sites/StateChemSML/SitePages/Product-line-products.aspx?PeramId=1"
              data-cke-saved-href="https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product-line-products.aspx?PeramId=1"
              data-interception="on"
              title="https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product-line-products.aspx?PeramId=1"
            >
              see all
            </a>
          </span>
        </div>
        <div className="container-fluid">
          <div className="row">
            {this.state.Products.length > 0
              ? this.state.Products.map((item) => (
                  <div className="col-lg-3 col-md-4 col-sm-6 col-xs-12 mar">
                    <a
                      href={
                        "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product.aspx?PeramId=" +
                        item.ID
                      }
                    >
                      <img
                        className="card-img-top"
                        src={item.AttachmentFiles[0].ServerRelativeUrl}
                        alt="images"
                      />

                      <div className="card-body">
                        <h5 className="card-text">{item.Title}</h5>
                        {/* <p className="card-text">{item.Description}</p> */}
                      </div>
                    </a>
                  </div>
                ))
              : ""}
          </div>
        </div>
      </>
    );
  }

  private logMessageToConsole(message: string) {
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    if (queryParms.getValue("PeramId")) {
      console.log(message);
    }
  }

  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Products')/items?$select=*,AttachmentFiles,Product_x0020_Line/ID&$expand=AttachmentFiles,Product_x0020_Line/ID&$filter=Product_x0020_Line/ID eq ` +
      id +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
}
