import * as React from "react";
import { IProductProps } from "./IProductProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface IProductstate {
    Products: any;
}
export default class Product extends React.Component<IProductProps, IProductstate> {
    ProductId: number;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IProductProps>;
    private logMessageToConsole;
    getData(id: any): Promise<any>;
}
//# sourceMappingURL=Product.d.ts.map