import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IProductProps {
    description: string;
    spfxcontext: WebPartContext;
}
//# sourceMappingURL=IProductProps.d.ts.map