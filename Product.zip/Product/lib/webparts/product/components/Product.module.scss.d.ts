declare const styles: {};
export default styles;
//# sourceMappingURL=Product.module.scss.d.ts.map