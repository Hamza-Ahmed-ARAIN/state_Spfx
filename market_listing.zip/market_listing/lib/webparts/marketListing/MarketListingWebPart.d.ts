import { Version } from "@microsoft/sp-core-library";
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
export interface IMarketListingWebPartProps {
    description: string;
    listcol: string;
    listName: string;
    listColOrderBy: string;
}
export default class MarketListingWebPart extends BaseClientSideWebPart<IMarketListingWebPartProps> {
    private _listDropDownOptions;
    private _colDropDownOptions;
    render(): void;
    protected onDispose(): void;
    protected onPropertyPaneConfigurationStart(): void;
    protected get dataVersion(): Version;
    getLists(): Promise<any>;
    getListColumns(listname: string): Promise<any>;
    protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=MarketListingWebPart.d.ts.map