import * as React from "react";
import { IMarketListingProps } from "./IMarketListingProps";
import "./style.css";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import "./style.css";
export interface IMarketWebState {
    items: any;
}
export default class MarketListing extends React.Component<IMarketListingProps, IMarketWebState> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IMarketListingProps>;
    getData(colName: any): Promise<any>;
}
//# sourceMappingURL=MarketListing.d.ts.map