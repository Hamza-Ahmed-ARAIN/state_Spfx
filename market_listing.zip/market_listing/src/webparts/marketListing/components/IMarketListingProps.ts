import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IMarketListingProps {
  description: string;
  listCol: string;
  listName: string;
  listColOrderBy: string;
  spfxcontext: WebPartContext;
}
