/* tslint:disable */
require("./MarketListing.module.css");
const styles = {
  marketListing: 'marketListing_5eb70874',
  container: 'container_5eb70874',
  row: 'row_5eb70874',
  column: 'column_5eb70874',
  'ms-Grid': 'ms-Grid_5eb70874',
  title: 'title_5eb70874',
  subTitle: 'subTitle_5eb70874',
  description: 'description_5eb70874',
  button: 'button_5eb70874',
  label: 'label_5eb70874'
};

export default styles;
/* tslint:enable */