declare interface IMarketListingWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MarketListingWebPartStrings' {
  const strings: IMarketListingWebPartStrings;
  export = strings;
}
