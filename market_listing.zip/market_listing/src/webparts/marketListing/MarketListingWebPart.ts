import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";

import MarketListing from "./components/MarketListing";
import { IMarketListingProps } from "./components/IMarketListingProps";
import {
  IPropertyPaneConfiguration,
  PropertyPaneDropdown,
  PropertyPaneTextField,
  IPropertyPaneDropdownOption,
} from "@microsoft/sp-property-pane";

import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import {
  PropertyFieldListPicker,
  PropertyFieldListPickerOrderBy,
} from "@pnp/spfx-property-controls/lib/PropertyFieldListPicker";

import * as strings from "MarketListingWebPartStrings";
export interface IMarketListingWebPartProps {
  description: string;
  listcol: string;
  listName: string;
  listColOrderBy: string;
}

export default class MarketListingWebPart extends BaseClientSideWebPart<IMarketListingWebPartProps> {
  private _listDropDownOptions: IPropertyPaneDropdownOption[] = [];
  private _colDropDownOptions: IPropertyPaneDropdownOption[] = [];

  public render(): void {
    const element: React.ReactElement<IMarketListingProps> =
      React.createElement(MarketListing, {
        description: this.properties.description,
        listCol: this.properties.listcol,
        listName: this.properties.listName,
        listColOrderBy: this.properties.listColOrderBy,
        spfxcontext: this.context,
      });

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected onPropertyPaneConfigurationStart(): void {
    console.log("this.context onPropertyPaneConfigurationStart", this.context);

    if (this._listDropDownOptions.length > 0) {
      return;
    }
    this.getLists()
      .then((res) => {
        for (let index = 0; index < res.value.length; index++) {
          this._listDropDownOptions.push({
            key: res.value[index].Id,
            text: res.value[index].Title,
          });
        }
        this.context.propertyPane.refresh();
        console.log("Lists", res);
        if (this.properties.listName) {
          return this.getListColumns(this.properties.listName);
        }
      })
      .then((response) => {
        if (response && response.value.length > 0) {
          console.log("list cols res", response);
          for (let index = 0; index < response.value.length; index++) {
            this._colDropDownOptions.push({
              key: response.value[index].InternalName,
              text: response.value[index].Title,
            });
          }
        } else {
          this._colDropDownOptions = [];
        }

        this.context.propertyPane.refresh();
      });
  }
  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }
  public async getLists(): Promise<any> {
    let ListURL: string = `${this.context.pageContext.web.absoluteUrl}/_api/web/lists?$filter=Hidden eq false and BaseTemplate eq 100&$select=Id,Title`;
    try {
      return this.context.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
  public async getListColumns(listname: string): Promise<any> {
    console.log("list cols getListColumns", listname);
    let ListURL: string = `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbyid('${listname}')/fields?$filter=Hidden eq false and ReadOnlyField eq false`;
    try {
      return this.context.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
  protected onPropertyPaneFieldChanged(
    propertyPath: string,
    oldValue: any,
    newValue: any
  ): void {
    if (propertyPath === "listName" && newValue != oldValue) {
      this._colDropDownOptions = [];
      this.getListColumns(this.properties.listName).then((response) => {
        if (response && response.value.length > 0) {
          console.log("list cols res onPropertyPaneFieldChanged", response);
          for (let index = 0; index < response.value.length; index++) {
            this._colDropDownOptions.push({
              key: response.value[index].InternalName,
              text: response.value[index].Title,
            });
          }
          this.context.propertyPane.refresh();
        } else {
          this._colDropDownOptions = [];
        }
      });
      this.context.propertyPane.refresh();
    }
  }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: "",
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
                // PropertyPaneTextField('listName', {
                //   label: "Enter List Name",

                // }),
                PropertyFieldListPicker("listName", {
                  label: "Select a list",
                  selectedList: this.properties.listName,
                  includeHidden: false,
                  orderBy: PropertyFieldListPickerOrderBy.Title,
                  disabled: false,
                  baseTemplate: 100,
                  onPropertyChange: this.onPropertyPaneFieldChanged.bind(this),
                  properties: this.properties,
                  context: this.context,
                  onGetErrorMessage: null,
                  key: "listPickerFieldId",
                }),
                //   PropertyPaneDropdown("listName",{label:"select your list",options:this._listDropDownOptions,

                // }),
                PropertyPaneDropdown("listcol", {
                  label: "TiTle",
                  options: this._colDropDownOptions,
                }),
                PropertyPaneDropdown("listColOrderBy", {
                  label: "Sort",
                  options: this._colDropDownOptions,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
