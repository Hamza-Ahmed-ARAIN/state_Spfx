import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IVariationProps {
    description: string;
    spfxcontext: WebPartContext;
    siteurl: string;
}
//# sourceMappingURL=IVariationProps.d.ts.map