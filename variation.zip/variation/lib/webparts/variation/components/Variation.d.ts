import * as React from "react";
import { IVariationProps } from "./IVariationProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface IVariationState {
    Variation: any;
}
export default class Varaition extends React.Component<IVariationProps, IVariationState> {
    private ProductId;
    private items;
    constructor(props: IVariationProps, state: IVariationState);
    componentDidMount(): void;
    render(): React.ReactElement<IVariationProps>;
    getDatavariation2(id: any): Promise<any>;
    getDatavariation3(id: any): Promise<any>;
    getData(id: any): Promise<any>;
    Product(id: any): Promise<any>;
}
//# sourceMappingURL=Variation.d.ts.map