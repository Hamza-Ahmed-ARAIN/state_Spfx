declare interface IVariationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'VariationWebPartStrings' {
  const strings: IVariationWebPartStrings;
  export = strings;
}
