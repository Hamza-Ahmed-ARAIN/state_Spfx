/* tslint:disable */
require("./Variation.module.css");
const styles = {
  variation: 'variation_dfa225bc',
  container: 'container_dfa225bc',
  row: 'row_dfa225bc',
  column: 'column_dfa225bc',
  'ms-Grid': 'ms-Grid_dfa225bc',
  title: 'title_dfa225bc',
  subTitle: 'subTitle_dfa225bc',
  description: 'description_dfa225bc',
  button: 'button_dfa225bc',
  label: 'label_dfa225bc'
};

export default styles;
/* tslint:enable */