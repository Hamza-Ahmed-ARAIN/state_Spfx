import * as React from "react";
import styles from "./Variation.module.scss";
import { IVariationProps } from "./IVariationProps";
import { escape } from "@microsoft/sp-lodash-subset";
import * as jquery from "jquery";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";

import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
export interface IVariationState {
  Variation: any;
}
let url = "";
let productName = "";
export default class Varaition extends React.Component<
  IVariationProps,
  IVariationState
> {
  private ProductId: number;
  private items: any = [];
  public constructor(props: IVariationProps, state: IVariationState) {
    super(props);
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    console.log("this is my id.." + this.ProductId);
    url = this.props.spfxcontext.pageContext.web.absoluteUrl;

    this.state = {
      Variation: [],
    };
  }
  public componentDidMount() {
    this.Product(this.ProductId).then((Response) => {
      productName = Response.value[0].Title;
      this.getData(Response.value[0].ProductNumber).then((response) => {
        console.log("here is my final data1", this.items);
        this.items.push(response.value[0]);
        this.getDatavariation2(Response.value[0].ProductNumber).then(
          (Response) => {
            console.log("here is my final data2", this.items);
            this.items.push(Response.value[0]);
            this.getDatavariation3(Response.value[0].ProductNumber).then(
              (Response1) => {
                console.log("here is my final data3", this.items);
                this.items.push(Response1.value[0]);
                console.log("here is my final data", this.items);
                this.setState({ Variation: this.items });
              }
            );
          }
        );
      });
    });
  }

  public render(): React.ReactElement<IVariationProps> {
    console.log(this.state.Variation);
    return (
      <div className="table-responsive">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th scope="col">Material Description</th>
              <th scope="col">Product Variation Name</th>
              <th scope="col">Standard Price</th>
              <th scope="col">Max Discount Percent</th>
              <th scope="col">F</th>
              <th scope="col">G</th>
              <th scope="col">GSA Price</th>

              {/* <th scope="col">Size</th> */}

              {/* <th scope="col">Floor Price</th> */}
              {/* <th scope="col">Give Price</th> */}

              {/* <th scope="col">State of Ohio Price</th>
          <th scope="col">State of Texas</th>
          <th scope="col">State of Louisiana</th>
          <th scope="col">State of Mississippi</th>
          <th scope="col">State of Pennsylvania</th> */}
            </tr>
          </thead>
          <tbody>
            {this.state.Variation.length > 0
              ? this.state.Variation.map((item) => (
                  <tr>
                    <td>{""}</td>
                    <td>{item.VariationName}</td>
                    <td>{item.StandardPrice}</td>
                    <td>{item.MaxDiscountPercent}</td>
                    <td>{item.F}</td>
                    <td>{item.G}</td>
                    <td>{item.GSAPrice}</td>

                    {/* <td>{item.ProductNumber}</td>

                    <td>{productName}</td> */}
                    {/* <td>{item.Size}</td>

                    <td>{item.FloorPrice}</td>
                    <td>{item.GivePrice}</td>

                    <td>{item.StateofOhioPrice}</td>
                    <td>{item.StateofTexas}</td>
                    <td>{item.StateofLouisiana}</td>
                    <td>{item.StateofMississippi}</td>
                    <td>{item.StateofPennsylvania}</td> */}
                  </tr>
                ))
              : ""}
          </tbody>
        </table>
      </div>
    );
  }
  public getDatavariation2(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Variation_US')/items?$filter=ProductNumber eq ` +
      id +
      ``;

    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
  public getDatavariation3(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Variation_PR')/items?$filter=ProductNumber eq ` +
      id +
      ``;

    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Variation_CA')/items?$filter=ProductNumber eq ` +
      id +
      ``;

    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
  public Product(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Products')/items?$filter=ID eq ` +
      id +
      ``;

    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
}
