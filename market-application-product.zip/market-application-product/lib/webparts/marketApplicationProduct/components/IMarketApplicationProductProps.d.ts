import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IMarketApplicationProductProps {
    description: string;
    spfxcontext: WebPartContext;
}
//# sourceMappingURL=IMarketApplicationProductProps.d.ts.map