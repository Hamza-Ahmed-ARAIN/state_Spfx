import * as React from "react";
import { IMarketApplicationProductProps } from "./IMarketApplicationProductProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface IMarketApplicationProductstate {
    Products: any;
}
export default class MarketApplicationProduct extends React.Component<IMarketApplicationProductProps, IMarketApplicationProductstate> {
    ProductId: number;
    filterId: string;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IMarketApplicationProductProps>;
    getData(id: any): Promise<any>;
    getApplication(filterId: any): Promise<any>;
}
//# sourceMappingURL=MarketApplicationProduct.d.ts.map