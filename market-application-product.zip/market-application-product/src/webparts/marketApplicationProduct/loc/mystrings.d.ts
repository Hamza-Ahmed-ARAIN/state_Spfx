declare interface IMarketApplicationProductWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MarketApplicationProductWebPartStrings' {
  const strings: IMarketApplicationProductWebPartStrings;
  export = strings;
}
