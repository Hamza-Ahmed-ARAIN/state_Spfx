import * as React from "react";
import styles from "./MarketApplicationProduct.module.scss";
import { IMarketApplicationProductProps } from "./IMarketApplicationProductProps";
import { escape } from "@microsoft/sp-lodash-subset";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
let url = "";
export interface IMarketApplicationProductstate {
  Products: any;
}
export default class MarketApplicationProduct extends React.Component<
  IMarketApplicationProductProps,
  IMarketApplicationProductstate
> {
  ProductId: number = null;
  filterId: string = "";
  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    // var  ProductId= parseInt(queryParms.getValue("ProductLineId"));
    this.state = {
      Products: [],
    };
    console.log("this is my id" + this.ProductId);

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
  }
  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      console.log(Response.value);
      Response.value[0].ProductsId.forEach((element) => {
        this.filterId += element + ",";
      });
      this.filterId = this.filterId.substring(0, this.filterId.length - 1);
      console.log("My data ", this.filterId);
      this.getApplication(this.filterId).then((response) => {
        console.log("this is my tes", response.value);
        this.setState({ Products: response.value });
      });
    });
  }
  public render(): React.ReactElement<IMarketApplicationProductProps> {
    return (
      <div className="container">
        <div className="head1">
          <h2>Hot Products</h2>
          <span className="seen1">
            <a
              href="https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product.aspx?PeramId=663"
              data-cke-saved-href="https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product.aspx?PeramId=663"
              data-interception="on"
              title="https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product.aspx?PeramId=663"
            >
              see all
            </a>
          </span>
        </div>
        <div className="row">
          {this.state.Products.length > 0
            ? this.state.Products.map((item) => (
                <div className="col-lg-3 col-md-4 col-sm-6 col-xs-12 mar">
                  <div className="card">
                    <a
                      href={
                        "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product.aspx?PeramId=" +
                        item.ID
                      }
                    >
                      <img
                        className="card-img-top"
                        src={item.AttachmentFiles[0].ServerRelativeUrl}
                        alt="images"
                      />

                      <div className="card-body">
                        <h5 className="card-text">{item.Title}</h5>
                      </div>
                    </a>
                  </div>
                </div>
              ))
            : ""}
        </div>
      </div>
    );
  }
  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Market')/items?$select=*,AttachmentFiles,Applications/ID&$expand=AttachmentFiles,Applications/ID&$filter=ID eq ` +
      id +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }

  public getApplication(filterId): Promise<any> {
    var query = "";
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    var filter = filterId.split(",");
    for (let i = 0; i < filter.length; i++) {
      query += "ID " + "eq " + filter[i] + " or ";
    }
    query = query.substring(0, query.length - 4);
    console.log(query);
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Products')/items?$select=*,AttachmentFiles&$expand=AttachmentFiles&$filter=` +
      query +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
}
