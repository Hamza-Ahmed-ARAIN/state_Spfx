/* tslint:disable */
require("./MarketApplicationProduct.module.css");
const styles = {
  marketApplicationProduct: 'marketApplicationProduct_26ddcea2',
  container: 'container_26ddcea2',
  row: 'row_26ddcea2',
  column: 'column_26ddcea2',
  'ms-Grid': 'ms-Grid_26ddcea2',
  title: 'title_26ddcea2',
  subTitle: 'subTitle_26ddcea2',
  description: 'description_26ddcea2',
  button: 'button_26ddcea2',
  label: 'label_26ddcea2'
};

export default styles;
/* tslint:enable */