/* tslint:disable */
require("./ApplicationCategories.module.css");
const styles = {
  applicationCategories: 'applicationCategories_e9209ef3',
  container: 'container_e9209ef3',
  row: 'row_e9209ef3',
  column: 'column_e9209ef3',
  'ms-Grid': 'ms-Grid_e9209ef3',
  title: 'title_e9209ef3',
  subTitle: 'subTitle_e9209ef3',
  description: 'description_e9209ef3',
  button: 'button_e9209ef3',
  label: 'label_e9209ef3'
};

export default styles;
/* tslint:enable */