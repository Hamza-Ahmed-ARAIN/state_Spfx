declare interface IApplicationCategoriesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ApplicationCategoriesWebPartStrings' {
  const strings: IApplicationCategoriesWebPartStrings;
  export = strings;
}
