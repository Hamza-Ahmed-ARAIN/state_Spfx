import * as React from "react";
import styles from "./CondosImg.module.scss";
import { ICondosImgProps } from "./ICondosImgProps";
import { escape } from "@microsoft/sp-lodash-subset";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { Markup } from "interweave";
import * as $ from "jquery";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import "./style.css";
let url = "";
export interface ICondosstate {
  Description: string;
  Title: string;
}
export default class CondosImg extends React.Component<
  ICondosImgProps,
  ICondosstate
> {
  ProductId: number = null;
  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    // var  ProductId= parseInt(queryParms.getValue("ProductLineId"));
    this.state = {
      Description: "",
      Title: "",
    };

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
  }
  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      var handle = this;
      var decodehtml = handle.htmlDecode(Response.value[0].Description);
      this.setState({
        Description: decodehtml,
        Title: Response.value[0].Title,
      });
    });
  }
  public render(): React.ReactElement<ICondosImgProps> {
    return (
      <div className="text-box col-12">
        <div>
          <div className="t-head">
            <h5>{this.state.Title}</h5>
          </div>
          <div className="t-cnt">
            <p>
              <Markup content={this.state.Description} />
            </p>
          </div>
        </div>
      </div>
    );
  }
  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Market')/items?,$filter=ID eq` +
      id +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
  public htmlDecode(value) {
    return $("<textarea/>").html(value).text();
  }
}
