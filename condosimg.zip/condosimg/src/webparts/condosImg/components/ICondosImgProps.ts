import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ICondosImgProps {
  description: string;
  spfxcontext: WebPartContext;
}
