/* tslint:disable */
require("./MmSlider.module.css");
const styles = {
  mmSlider: 'mmSlider_97abd407',
  container: 'container_97abd407',
  row: 'row_97abd407',
  column: 'column_97abd407',
  'ms-Grid': 'ms-Grid_97abd407',
  title: 'title_97abd407',
  subTitle: 'subTitle_97abd407',
  description: 'description_97abd407',
  button: 'button_97abd407',
  label: 'label_97abd407'
};

export default styles;
/* tslint:enable */