import * as React from "react";
import styles from "./MmSlider.module.scss";
import { IMmSliderProps } from "./IMmSliderProps";
import { escape } from "@microsoft/sp-lodash-subset";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import "../components/style.css";
import { SPComponentLoader } from "@microsoft/sp-loader";
// import Slider from "react-slick";
import Carousel from "react-elastic-carousel";
import styled from "styled-components";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
let COUNT;
const itemsPerPage = 3;
let totalPages;

// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
// const slide: string = require("../assets/1.jpg");
let url = "";
// var settings = {
//   dots: false,
//   infinite: true,
//   speed: 1,
//   slidesToShow: 1,
//   slidesToScroll: 1
// };
export interface IMmSliderState {
  items: any;
}

export default class MmSlider extends React.Component<
  IMmSliderProps,
  IMmSliderState
> {
  private carousel: any;
  ProductId: number = null;
  filterId: string = "";
  constructor(props) {
    super(props);

    this.goto = this.goto.bind(this);
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    this.state = {
      items: [],
    };

    url = this.props.spfxContext.pageContext.web.absoluteUrl;

    SPComponentLoader.loadCss(
      "https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css"
    );
  }
  goto(target: number) {
    this.carousel.goTo(target);
  }
  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      Response.value.forEach((element) => {
        this.filterId += element.RelatedProjectId + ",";
      });
      this.filterId = this.filterId.substring(0, this.filterId.length - 1);

      this.getApplication(this.filterId).then((response) => {
        this.setState({ items: response.value });
      });
    });
  }
  public render(): React.ReactElement<IMmSliderProps> {
    return (
      <div>
        <Carousel
          isRTL={false}
          pagination={false}
          showArrows={true}
          enableAutoPlay={true}
          ref={(ref) => (this.carousel = ref)}
          autoPlaySpeed={5000} // same time
          onNextEnd={(nextItemObject: any, currentPageIndex) => {
            if (COUNT == currentPageIndex) {
              setTimeout(
                function () {
                  this.goto(0);
                }.bind(this),
                5000
              );
            }
            // if (nextItemObject === currentPageIndex) {
            //   // we hit the last item, go to first item
            //   this.carouselRef.current;
            // }
          }}
          // ref={carouselRef}
          // onNextEnd={({ index }) => {
          //      clearTimeout(resetTimeout)
          //      if (index + 1 === totalPages) {
          //         resetTimeout = setTimeout(() => {
          //            carouselRef.current.goTo(0)
          //        }, 1500) // same time
          //      }
          // }}
          // itemsToShow={itemsPerPage}
        >
          {this.state.items.map((item) => {
            return (
              <div className="blar">
                <a href="" target="">
                  <img
                    className="d-block w-100"
                    src={
                      item.AttachmentFiles.length > 0
                        ? item.AttachmentFiles[0].ServerRelativeUrl
                        : ""
                    }
                    alt="No Image"
                    style={{ height: 240 }}
                  />
                </a>
                <div className="abc">
                  <a className="heading" href="" target="">
                    <h5 className="tr">{item.Title}</h5>
                  </a>
                </div>
              </div>
            );
          })}
        </Carousel>
      </div>
    );
  }
  // public async getData(id): Promise<any> {
  //   ///_api/web/lists/getbytitle('Site Pages')/items?$select=*,LinkFilenameNoMenu,Author/Title&$filter=PromotedState eq 2&$expand=Author&$orderby=Created desc
  //   // let ListURL:string=`${url}/_api/web/lists/getbytitle('mm')/items?$select=*,AttachmentFiles&$expand=AttachmentFiles`;
  //   let ListURL: string =
  //     `${url}/_api/web/lists/getbytitle('Related Products')/items?$select=*,Product_x0020_Line/ID&$expand=AttachmentFiles,Product_x0020_Line/ID&$filter=Product_x0020_Line/ID eq ` +
  //     id +
  //     ``;

  //   try {
  //     return this.props.spfxContext.spHttpClient
  //       .get(ListURL, SPHttpClient.configurations.v1)
  //       .then((response: SPHttpClientResponse) => {
  //         return response.json();
  //       });
  //   } catch (error) {
  //     console.dir(error);
  //     return Promise.reject(error);
  //   }
  // }

  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Related Products')/items?$select=*,AttachmentFiles,MasterProduct/ID,RelatedProject/ID,RelatedProject/Title&$expand=AttachmentFiles,MasterProduct/ID,RelatedProject/ID,RelatedProject/Title&$filter=MasterProduct/ID eq ` +
      id +
      ``;
    try {
      return this.props.spfxContext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      return Promise.reject(error);
    }
  }
  public getApplication(filterId): Promise<any> {
    var query = "";
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    var filter = filterId.split(",");
    for (let i = 0; i < filter.length; i++) {
      query += "ID " + "eq " + filter[i] + " or ";
    }
    query = query.substring(0, query.length - 4);

    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Products')/items?$select=*,AttachmentFiles&$expand=AttachmentFiles&$filter=` +
      query +
      ``;
    try {
      return this.props.spfxContext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
