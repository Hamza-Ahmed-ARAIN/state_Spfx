declare interface IMmSliderWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MmSliderWebPartStrings' {
  const strings: IMmSliderWebPartStrings;
  export = strings;
}
