import * as React from "react";
import { IMmSliderProps } from "./IMmSliderProps";
import "../components/style.css";
export interface IMmSliderState {
    items: any;
}
export default class MmSlider extends React.Component<IMmSliderProps, IMmSliderState> {
    private carousel;
    ProductId: number;
    filterId: string;
    constructor(props: any);
    goto(target: number): void;
    componentDidMount(): void;
    render(): React.ReactElement<IMmSliderProps>;
    getData(id: any): Promise<any>;
    getApplication(filterId: any): Promise<any>;
}
//# sourceMappingURL=MmSlider.d.ts.map