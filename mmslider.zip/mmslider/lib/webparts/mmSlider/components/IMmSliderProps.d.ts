import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IMmSliderProps {
    description: string;
    spfxContext: WebPartContext;
}
//# sourceMappingURL=IMmSliderProps.d.ts.map