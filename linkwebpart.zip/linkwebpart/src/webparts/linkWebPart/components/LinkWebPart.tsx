import * as React from "react";
import styles from "./LinkWebPart.module.scss";
import { ILinkWebPartProps } from "./ILinkWebPartProps";
import { escape } from "@microsoft/sp-lodash-subset";
import { SPComponentLoader } from "@microsoft/sp-loader";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import "./style.css";
export interface ILinkWebState {
  items: any;
}
let url = "";
let colName;
export default class LinkWebPart extends React.Component<
  ILinkWebPartProps,
  ILinkWebState
> {
  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );
    this.state = {
      items: [],
    };

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
    colName = this.props.listCol;
    console.log("Site Url", url);
  }
  componentDidMount() {
    console.log("ListName in DidMount: ", this.props.listCol);

    // this.getListColumns().then((res) => {
    //   console.log("List Columns", res.value);
    // });
    this.getData(this.props.listCol).then((res) => {
      console.log("this is my response", res.value);

      if (res.value.length > 0) {
        let data = [];
        res.value.forEach((element) => {
          let FilesUrls = [];
          let FileNames = [];
          var Id = null;
          if (element.AttachmentFiles.length != 0) {
            for (var i = 0; i < element.AttachmentFiles.length; i++) {
              FilesUrls.push(element.AttachmentFiles[i].ServerRelativeUrl);
              FileNames.push(element.AttachmentFiles[i].FileName);
            }
          }
          data.push({
            Name: element[colName],
            FileNames: FileNames,
            ServerRelativeUrls: FilesUrls,
            ID: element["ID"],
          });
          console.log("data.push", data);

          // data.push({ Name: element.Name.Title, Description: element.Description, Post: element.Post, Title: element.Title, FileNames: FileNames, ServerRelativeUrls: FilesUrls });
        });

        this.setState({ items: data });
      }
    });
  }
  public render(): React.ReactElement<ILinkWebPartProps> {
    console.log("colName in render: ", this.props.listCol);
    console.log("ListName in render: ", this.props.listName);

    return (
      <div className="container">
        <div className="row">
          {this.state.items.length > 0
            ? this.state.items.map((item) => (
                <div className="col-lg-3 col-md-4 col-sm-6 col-xs-12 mar">
                  <div className="card">
                    <a
                      href={
                        this.props.listName ==
                        "df90ae4b-62ca-4140-89b9-fc7c6cf7414a"
                          ? "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Application-Products.aspx?PeramId=" +
                            item.ID
                          : this.props.listName ==
                            "d10653cd-6bea-4c12-847b-9e20871d561e"
                          ? "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Market-Category.aspx?PeramId=" +
                            item.ID
                          : "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product-line.aspx?PeramId=" +
                            item.ID
                      }
                    >
                      <img
                        className="card-img-top"
                        src={item.ServerRelativeUrls[0]}
                        alt="images"
                      />
                      <div className="card-body">
                        <h5 className="card-text">{item.Name}</h5>
                      </div>
                    </a>
                  </div>
                </div>
              ))
            : ""}
        </div>
      </div>
    );
  }

  public async getData(colName): Promise<any> {
    let ListURL: string = `${url}/_api/web/lists/getbyid('${this.props.listName}')/items?$select=${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('ForChoice')/items?$select=*,AttachmentFiles&$expand=AttachmentFiles&$Id=4`;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }

  // public async getListColumns(): Promise<any> {
  //   let ListURL:string=`${url}/_api/web/lists/getbytitle('${this.props.listName}')/fields?$filter=Hidden eq false and ReadOnlyField eq false`;
  //   try {
  //     return this.props.spfxcontext.spHttpClient.get(ListURL, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
  //       return response.json();
  //     });
  //   } catch (error) {
  //     console.dir(error);
  //     return Promise.reject(error);
  //   }
  // }
}
