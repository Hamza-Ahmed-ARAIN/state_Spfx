/* tslint:disable */
require("./LinkWebPart.module.css");
const styles = {
  linkWebPart: 'linkWebPart_2d0ad298',
  container: 'container_2d0ad298',
  row: 'row_2d0ad298',
  column: 'column_2d0ad298',
  'ms-Grid': 'ms-Grid_2d0ad298',
  title: 'title_2d0ad298',
  subTitle: 'subTitle_2d0ad298',
  description: 'description_2d0ad298',
  button: 'button_2d0ad298',
  label: 'label_2d0ad298'
};

export default styles;
/* tslint:enable */