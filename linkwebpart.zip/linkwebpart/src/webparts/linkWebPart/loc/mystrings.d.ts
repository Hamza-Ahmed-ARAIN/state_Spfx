declare interface ILinkWebPartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LinkWebPartWebPartStrings' {
  const strings: ILinkWebPartWebPartStrings;
  export = strings;
}
