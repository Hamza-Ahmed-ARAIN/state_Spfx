import { Version } from "@microsoft/sp-core-library";
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
export interface ILinkWebPartWebPartProps {
    description: string;
    listcol: string;
    listName: string;
    listColOrderBy: string;
}
export default class LinkWebPartWebPart extends BaseClientSideWebPart<ILinkWebPartWebPartProps> {
    private _listDropDownOptions;
    private _colDropDownOptions;
    render(): void;
    protected onDispose(): void;
    protected onPropertyPaneConfigurationStart(): void;
    protected get dataVersion(): Version;
    getLists(): Promise<any>;
    getListColumns(listname: string): Promise<any>;
    protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=LinkWebPartWebPart.d.ts.map