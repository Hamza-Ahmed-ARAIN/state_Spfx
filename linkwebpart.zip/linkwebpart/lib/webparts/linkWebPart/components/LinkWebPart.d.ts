import * as React from "react";
import { ILinkWebPartProps } from "./ILinkWebPartProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import "./style.css";
export interface ILinkWebState {
    items: any;
}
export default class LinkWebPart extends React.Component<ILinkWebPartProps, ILinkWebState> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<ILinkWebPartProps>;
    getData(colName: any): Promise<any>;
}
//# sourceMappingURL=LinkWebPart.d.ts.map