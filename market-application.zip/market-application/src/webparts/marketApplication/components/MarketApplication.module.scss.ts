/* tslint:disable */
require("./MarketApplication.module.css");
const styles = {
  marketApplication: 'marketApplication_b26b60f7',
  container: 'container_b26b60f7',
  row: 'row_b26b60f7',
  column: 'column_b26b60f7',
  'ms-Grid': 'ms-Grid_b26b60f7',
  title: 'title_b26b60f7',
  subTitle: 'subTitle_b26b60f7',
  description: 'description_b26b60f7',
  button: 'button_b26b60f7',
  label: 'label_b26b60f7'
};

export default styles;
/* tslint:enable */