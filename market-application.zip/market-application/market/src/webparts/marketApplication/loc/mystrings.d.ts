declare interface IMarketApplicationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MarketApplicationWebPartStrings' {
  const strings: IMarketApplicationWebPartStrings;
  export = strings;
}
