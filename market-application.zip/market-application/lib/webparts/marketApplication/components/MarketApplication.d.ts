import * as React from "react";
import { IMarketApplicationProps } from "./IMarketApplicationProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface IMarketApplicationstate {
    Applications: any;
}
export default class MarketApplication extends React.Component<IMarketApplicationProps, IMarketApplicationstate> {
    ProductId: number;
    filterId: string;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IMarketApplicationProps>;
    getData(id: any): Promise<any>;
    getApplication(filterId: any): Promise<any>;
}
//# sourceMappingURL=MarketApplication.d.ts.map