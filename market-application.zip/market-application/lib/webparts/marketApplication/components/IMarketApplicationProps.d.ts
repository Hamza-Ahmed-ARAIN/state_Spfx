import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IMarketApplicationProps {
    description: string;
    spfxcontext: WebPartContext;
}
//# sourceMappingURL=IMarketApplicationProps.d.ts.map